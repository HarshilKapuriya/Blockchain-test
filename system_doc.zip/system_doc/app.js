
// ------------------- Contract Setup -------------------
const contractAddress = "0xe84480E18dB36164e1a635f45Cfb6C1B3944C7b6"; // 👈 replace with your deployed contract
const contractABI = [
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "string",
				"name": "fileHash",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			}
		],
		"name": "DocumentUploaded",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_fileHash",
				"type": "string"
			}
		],
		"name": "uploadDocument",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_fileHash",
				"type": "string"
			}
		],
		"name": "verifyDocument",
		"outputs": [
			{
				"internalType": "bool",
				"name": "exists",
				"type": "bool"
			},
			{
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

// ------------------- Providers -------------------
// 👇 Use Sepolia testnet RPC (change if using Ganache/local/other network)
const RPC_URL = "https://sepolia.infura.io/v3/a1e9905236e14dcf8483d0db3109789c"; 
const readProvider = new ethers.providers.JsonRpcProvider(RPC_URL);

// ------------------- DOM Elements -------------------
const form = document.getElementById("uploadForm");
const fileInput = document.getElementById("fileInput");
const submitButton = document.getElementById("submitButton");
const statusDiv = document.getElementById("status");

// ------------------- Utility Functions -------------------
async function getFileHash(file) {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
  return "0x" + Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

// ------------------- Main Logic -------------------
window.addEventListener("load", async () => {
  let signer = null;
  let isAdmin = false;

  try {
    // Connect to MetaMask if available
    if (window.ethereum) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      signer = provider.getSigner();
    }

    // Form submit handler
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const file = fileInput.files[0];
      if (!file) return alert("Please select a file!");

      statusDiv.innerText = "⏳ Calculating file hash...";
      const hash = await getFileHash(file);

      try {
        if (signer) {
          // Admin mode (upload + verify)
          const contract = new ethers.Contract(contractAddress, contractABI, signer);

          statusDiv.innerText = "📤 Uploading document...";
          const tx = await contract.uploadDocument(hash);
          await tx.wait();

          statusDiv.innerText = `✅ Document uploaded!\nHash: ${hash}`;
        } else {
          // User mode (verify only)
          const contract = new ethers.Contract(contractAddress, contractABI, readProvider);
          const [exists, owner, timestamp] = await contract.verifyDocument(hash);

          if (exists) {
            statusDiv.innerText = `✅ Document is REAL!\nOwner: ${owner}\nTime: ${new Date(timestamp.toNumber() * 1000)}`;
          } else {
            statusDiv.innerText = "❌ Document is FAKE!";
          }
        }
      } catch (err) {
        statusDiv.innerText = `⚠️ Error: ${err.message}`;
      }
    });
  } catch (err) {
    statusDiv.innerText = `⚠️ Error: ${err.message}`;
  }
});
